//
//  SecurityFramework.h
//  SecurityFramework
//
//  Created by Amauri Viturino on 15/08/2018.
//  Copyright © 2018 Amauri Viturino. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SecurityFramework.
FOUNDATION_EXPORT double SecurityFrameworkVersionNumber;

//! Project version string for SecurityFramework.
FOUNDATION_EXPORT const unsigned char SecurityFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SecurityFramework/PublicHeader.h>

#import <SecurityFramework/SecurityInterface.h>


