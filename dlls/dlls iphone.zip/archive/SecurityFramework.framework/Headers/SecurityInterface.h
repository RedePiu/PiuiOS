//
//  SecurityInterface.h
//  SecurityFramework
//
//  Created by Amauri Viturino on 15/08/2018.
//  Copyright © 2018 Amauri Viturino. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SecurityInterface : NSObject

+ (void)helloWithText:(NSString *) text;
+ (int)iT;
+ (NSString *) cA:(NSString *) a:(int) t: (long) s;
+ (int) vA:(NSString *) a:(int) t: (long) s: (NSString *) f;
+ (NSString *) gB;
+ (int)vB:(NSString *) b;
+ (int)tC;
+ (int) sS:(NSString *) a:(int) t: (long) s;
+ (int) sT:(NSString *) a:(int) t: (long) s;
+ (NSString *) cS:(NSString *) a:(NSString *) b:(int) t: (long) s;
+ (int) sTA:(NSString *) p;
+ (NSString *) gTP;

@end
